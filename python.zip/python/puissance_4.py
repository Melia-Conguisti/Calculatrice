﻿""" Puissance 4"""

#6 rangées et 7 colonnes

from tkinter import *

def victoire():
    #les horizontales:
    for i in range(0, 6):
        for j in range(0, 4):
            somme = grille[i][j] + grille[i][j + 1] + grille[i][j + 2] + grille[i][j + 3]
            if somme == 4 or somme == -4:
                return True

    #les verticales:
    for i in range(0, 3):
        for j in range(0, 7):
            somme1 = grille[i][j] + grille[i + 1][j] + grille[i + 2][j] + grille[i + 3][j]
            if somme1 == 4 or somme == -4:
                return True

    #les diagonales de gauche à droite:
    for i in range(0, 3):
        for j in range(3, 7):
            somme2 = grille[i][j] + grille[i + 1][j - 1] + grille[i + 2][j - 2] + grille[i + 3][j - 3]
            if somme2 == 4 or somme2 == -4:
                return True

    #les diagonales de droite à gauche:
    for i in range(0, 3):
        for j in range(0, 4):
            somme3 = grille[i][j] + grille[i + 1][j + 1] + grille[i + 2][j + 2] + grille[i + 3][j + 3]
            if somme3 == 4 or somme3 == -4:
                return True





def pointeur(event):
    global tour
    if tour % 2 == 0:
        couleur = "red"
    else:
        couleur = "yellow"

    colonne = (event.x - 10) // 100

    if grille[0][colonne] == 0:
        tour = tour + 1
        n_ligne = 0
        while n_ligne < 6:
            if grille[n_ligne][colonne] == 0:
                n_ligne = n_ligne + 1
            else:
                break

        n_ligne = n_ligne - 1

        can.create_oval(10 + colonne * 100, 10 + n_ligne * 100, 10 + (colonne + 1) * 100, 110 + n_ligne*100, fill= couleur)
        if tour % 2 == 0:
            grille[n_ligne][colonne] = 1
        else:
            grille[n_ligne][colonne] = -1
    if victoire():
        print(couleur, "a gagné!")


fen = Tk()
fen.geometry('750x650+10+10')
# geometry("largeurxhauteur+Δ largeur+Δ hauteur")
# deux nombres autour d'un x minuscule pour dimensionner la fenêtre
# puis deux nombres pour positionner la fenêter dans l'écran

fen.title("Puissance 4")

can = Canvas(fen,bg='lightblue',height=620,width=720)
can.pack(side=LEFT)


#Creation de la grille

#les horizontales
for i in range(7):
    can.create_line(10, 10 + 100 * i, 710, 10 + 100 * i, fill ='white')

#Les versitcales
for i in range(8):
    can.create_line(10 + 100 * i, 10 , 10 + 100 * i, 610, fill ='white')


can.bind("<Button-1>", pointeur)
can.pack()

tour = 0
grille = []
for i in range(6):
    ligne =  []
    for j in range(7):
        ligne.append(0)
    grille.append(ligne)


bou1 = Button(fen, text = 'quitter', fg='black', bg='lightblue', command = fen.destroy)
bou1.pack(side = BOTTOM)

text2 = Label(fen, text = victoire, fg="black", font=('calibri',20,'bold'))
text2.pack()

fen.mainloop()