﻿# Détection et positionnement d'un clic de souris dans une fenêtre :
from tkinter import *

def pointeur(event):
    chaine.configure(text = "Clic détecté en X =" + str(event.x) +\
                             ", Y =" +\
                              str(event.y))


fen = Tk()
cadre = Frame(fen, width =200, height =150, bg="light yellow")
# un frame est un conteneur pour éventuellement plusieurs widgets
# un Canvas est fait pour faire des dessins
cadre.bind("<Button-1>", pointeur)
cadre.pack()
chaine = Label(fen)
chaine.pack()
fen.mainloop()

# voir swinnen page 98 pour les 15 classes de base de widget de tkinter