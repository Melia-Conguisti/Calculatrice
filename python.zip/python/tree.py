import turtle


def tree(
    branch,
    level,
    angle,
    length,
    factor=0.7
):
    # La dernière branche est atteinte.
    if level == 0:
        return None

    # Assigne une couleur en fonction du niveau (level) de la branche.
    turtle.colormode(255)
    turtle.pencolor(0, 255 // level, 0)

    # Assigne une taille en fonction de la longueur (length) de la branche.
    turtle.pensize(length / 25)

    # Dessine la branche courante.
    turtle.forward(length)

    # Recalage de l'angle.
    correct_angle = (branch - 1) * angle / 2
    turtle.right(correct_angle)

    for _ in range(branch):
        tree(branch, level - 1, angle, length * factor)
        turtle.left(angle)

    turtle.right(correct_angle * 2)
    turtle.up()
    turtle.backward(length)
    turtle.down()


# Initialisation de la tortue.
turtle.speed('fastest')
turtle.left(90)

# Création de l'arbre.
tree(branch=3, level=5, angle=45, length=100)

turtle.exitonclick()
