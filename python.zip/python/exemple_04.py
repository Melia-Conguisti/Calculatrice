﻿# Exercice utilisant la bibliothèque graphique tkinter et le module math
from tkinter import *
from math import *

# définition de l'action à effectuer si l'utilisateur actionne
# la touche "entrée" alors qu'il édite le champ d'entrée :
def evaluer(event):
    chaine.configure(text = "Résultat = " + str(eval(entree.get())))
    # entree.get() chose importante à observer
    # récupère la chaine de caractères placée par l'utilisateur dans entree


# ----- Programme principal : -----
fenetre = Tk()

entree = Entry(fenetre) # création d'une zone de texte pour l'utilisateur
entree.bind("<Return>", evaluer) # bind lie l'appuis sur <Return> dans la zone
                                 # de texte de entree avec la fonction <evaluer>
chaine = Label(fenetre)
entree.pack()
chaine.pack()
fenetre.mainloop()

