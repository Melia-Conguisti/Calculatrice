﻿def saisie(joueur, nombre_craies):
    nombre_enleve = 100
    while not 1 <= nombre_enleve <= 3 or nombre_enleve > nombre_craies:
        try:
            nombre_enleve = int(input('{} : enlèves 1, 2 ou 3 craie(s)\n> '.format(joueur)))
        except:
            print('Veuillez saisir 1, 2 ou 3.')
    return nombre_enleve


choix = ''
while choix != '1' and choix != '2':
    choix = input('Mode de jeux :\n  1; Joueur VS joueur\n  2; Joueur VS IA\n> ')

nombre_craies = 21

if choix =='1':
    while nombre_craies > 0:
        for joueur in ('Joueur 1', 'Joueur 2'):
            nombre_craies = nombre_craies - saisie(joueur, nombre_craies)
            if nombre_craies <= 0:
              print(joueur, 'a perdu.')
              break
            print("il reste", nombre_craies, "craie(s)")
            print('|' * nombre_craies + '\n')

else:
    while nombre_craies > 0:
        nombre_craies = nombre_craies - saisie('joueur', nombre_craies)
        if nombre_craies == 0:
            break
        print('|' * nombre_craies + '\n')
        for craies in [17, 13, 9, 5, 1]:                
            if nombre_craies > craies:
                print('L’IA a enlevé', nombre_craies - craies, 'craies')
                nombre_craies = craies
                break
        print('|' * nombre_craies + '\n')
    print('le joueur a perdu')



