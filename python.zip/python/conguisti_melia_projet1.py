﻿mini = 0
maxi = 100
compt = 0

for i in range(7):
    nb = int((mini + maxi)/2)
    compt = compt+1
    print('Coup numéro :', compt, '\nNombre proposé :', nb)
    reponse = 0
    while not 0 < reponse <= 3:
        try:
            reponse = int(input('1 : Trop petit, 2 : Bien joué !, 3 : Trop grand\n> '))
        except:
            print('Veuillez saisir 1, 2 ou 3.')

    if reponse == 1:
        print('Trop petit')
        mini = nb + 1
    elif reponse == 2:
        print('Bien joué !')
        break
    elif reponse == 3:
        print('Trop grand')
        maxi = nb - 1