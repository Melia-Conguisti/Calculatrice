from tkinter import *

class game:
    def __init__(self):
        self.mini = 0
        self.maxi = 100

        self.root = Tk()
        self.root.title('Juste Prix')

        Label(self.root, text="Voici les règles du jeux:\nPenses à un nombe entre 1 et 100. \nEt appuies sur 'Trop petit', 'Bon' ou 'Trop grand'").pack()

        self.nb_tk = IntVar()
        self.nb_tk.set(50)
        Label(self.root, textvariable=self.nb_tk).pack()

        Button(self.root, text="Trop petit", command=self.trop_petit).pack()
        Button(self.root, text="Trop grand", command=self.trop_grand).pack()
        Button(self.root, text="Bon", command=self.bon).pack()

        self.root.mainloop()

    def trop_petit(self):
        self.mini = self.nb_tk.get() + 1
        self.calcul()

    def trop_grand(self):
        self.maxi = self.nb_tk.get() - 1
        self.calcul()

    def bon(self):
        pass

    def calcul(self):
        self.nb_tk.set(int((self.mini + self.maxi) / 2))

game()